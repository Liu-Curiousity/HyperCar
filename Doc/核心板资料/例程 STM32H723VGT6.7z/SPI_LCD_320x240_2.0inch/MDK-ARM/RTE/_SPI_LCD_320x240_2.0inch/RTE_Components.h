
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'SPI_LCD_320x240_2.0inch' 
 * Target:  'SPI_LCD_320x240_2.0inch' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32h7xx.h"



#endif /* RTE_COMPONENTS_H */
